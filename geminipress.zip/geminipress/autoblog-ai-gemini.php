<?php
/**
 * Plugin Name: GeminiPress
 * Plugin URI: https://ebot.my.id/product/geminipress
 * Description: Autoblog Auto Posting Artikel AI menggunakan Gemini AI API (1).Set & Forget dengan Cronjob, (2).Bulk Posting juga bisa
 * Version: 1.9.46
 * Author: Rifan Muazin
 * Author URI: https://facebook.com/rifanmuazin
 * Update URI: https://update.ebot.my.id/geminipress.json
 */
 
require 'Parsedown.php';
require 'gemini.php';
if (!defined('ABSPATH')) exit; // 
// ==========================
// 1. REGISTER CUSTOM POST TYPE
// ==========================
function autoblog_register_post_type() {
    register_post_type('autoblog', array(
        'labels' => array(
            'name'               => 'GeminiPress',
            'singular_name'      => 'Template GeminiPress',
            'add_new'            => 'Add New Template',
            'add_new_item'       => 'Add New Template',
            'edit_item'          => 'Edit Template',
            'new_item'           => 'New Template',
            'view_item'          => 'View Template',
            'view_items'         => 'View Templates',
            'search_items'       => 'Search Templates',
            'not_found'          => 'No Templates found',
            'not_found_in_trash' => 'No Templates found in Trash',
            'all_items'          => 'All Templates',
            'menu_name'          => 'Template AI',
            'name_admin_bar'     => 'GeminiPress',
        ),
        'public'             => true,
        'has_archive'        => false,
        'menu_icon'          => 'dashicons-admin-post',
        'supports'           => array('title'),
        'show_in_rest'       => true, // <-- penting
        'rest_base'          => 'autoblog', // endpoint URL
        'rest_controller_class' => 'WP_REST_Posts_Controller',
    ));
}
add_action('init', 'autoblog_register_post_type');

// ==========================
// 2. REGISTER META FIELDS FOR REST
// ==========================
function autoblog_rest_add_meta_to_response($data, $post, $context) {
    if ($post->post_type === 'autoblog') {
        $meta_fields = [
            '_autoblog_api_key',
            '_autoblog_model',
            '_autoblog_temperature',
            '_autoblog_max_tokens',
            '_autoblog_top_p',
            '_autoblog_top_k',
            '_autoblog_prompt',
            '_autoblog_keywords',
            '_autoblog_template_article',
            '_autoblog_category',
            '_autoblog_tags',
            '_autoblog_image_option',
            '_autoblog_image_fail_action',
            '_autoblog_publish_option',
			'_autoblog_user_id',
			'_autoblog_title',
        ];

        foreach ($meta_fields as $meta_key) {
            $meta_value = get_post_meta($post->ID, $meta_key, true);
            if ($meta_value !== '') {
                $data->data[$meta_key] = $meta_value;
            }
        }
    }

    return $data;
}
add_filter('rest_prepare_autoblog', 'autoblog_rest_add_meta_to_response', 10, 3);

// ==========================
// 3. INCLUDE META DATA IN REST API RESPONSE
// ==========================
add_action('rest_api_init', 'autoblog_register_meta_fields');

function autoblog_register_meta_fields() {
    register_post_meta('autoblog', 'autoblog_status', array(
        'show_in_rest' => true,
        'type'         => 'string',
        'single'       => true,
        'auth_callback' => function() {
            return current_user_can('edit_posts');
        }
    ));

    register_post_meta('autoblog', 'autoblog_url', array(
        'show_in_rest' => true,
        'type'         => 'string',
        'single'       => true,
        'auth_callback' => function() {
            return current_user_can('edit_posts');
        }
    ));
}



// ==========================
// 4. CLONE / DUPLICATE POST
// ==========================
function autoblog_duplicate_post_as_draft() {
    global $wpdb;

    if (!isset($_GET['post']) || !isset($_REQUEST['action']) || $_REQUEST['action'] !== 'autoblog_duplicate_post_as_draft') {
        wp_die('No post to duplicate has been supplied!');
    }

    $post_id = absint($_GET['post']);
    $post = get_post($post_id);

    if ($post) {
        $new_post = array(
            'post_title'  => $post->post_title . ' (Copy)',
            'post_content'=> $post->post_content, // Salin isi artikel
            'post_status' => 'draft',
            'post_type'   => $post->post_type,
            'post_author' => get_current_user_id(),
        );

        $new_post_id = wp_insert_post($new_post);

        // Salin semua custom field (post meta)
        $meta_data = get_post_meta($post_id);
        foreach ($meta_data as $key => $values) {
            foreach ($values as $value) {
                add_post_meta($new_post_id, $key, maybe_unserialize($value));
            }
        }

        // Salin semua kategori & tag (taxonomy)
        $taxonomies = get_object_taxonomies($post->post_type);
        foreach ($taxonomies as $taxonomy) {
            $terms = wp_get_object_terms($post_id, $taxonomy, array('fields' => 'slugs'));
            wp_set_object_terms($new_post_id, $terms, $taxonomy, false);
        }

        // Redirect kembali ke halaman post list
        wp_redirect(admin_url('edit.php?post_type=autoblog'));
        exit;
    } else {
        wp_die('Post creation failed, could not find original post.');
    }
}
add_action('admin_action_autoblog_duplicate_post_as_draft', 'autoblog_duplicate_post_as_draft');

function autoblog_duplicate_post_link($actions, $post) {
    if ($post->post_type == 'autoblog') {
        $actions['duplicate'] = '<a href="' . wp_nonce_url('admin.php?action=autoblog_duplicate_post_as_draft&post=' . $post->ID, basename(__FILE__), 'duplicate_nonce') . '" title="Duplicate this item" rel="permalink">Duplicate</a>';
    }
    return $actions;
}
add_filter('post_row_actions', 'autoblog_duplicate_post_link', 10, 2);

// ==========================
// 5. BULK DELETE POSTS
// ==========================
function autoblog_bulk_actions($bulk_actions) {
    $bulk_actions['delete_autoblog_posts'] = 'Delete Selected';
    return $bulk_actions;
}
add_filter('bulk_actions-edit-autoblog', 'autoblog_bulk_actions');

function autoblog_bulk_delete_posts($redirect_to, $doaction, $post_ids) {
    if ($doaction !== 'delete_autoblog_posts') {
        return $redirect_to;
    }

    foreach ($post_ids as $post_id) {
        wp_delete_post($post_id, true);
    }

    $redirect_to = add_query_arg('bulk_deleted_posts', count($post_ids), $redirect_to);
    return $redirect_to;
}
add_filter('handle_bulk_actions-edit-autoblog', 'autoblog_bulk_delete_posts', 10, 3);

// ==========================
// 6. BULK EDIT (Custom Field Example)
// ==========================
function autoblog_add_bulk_edit_custom_box($column_name, $post_type) {
    if ($post_type == 'autoblog' && $column_name == 'title') {
        echo '<fieldset class="inline-edit-col-right">
                <div class="inline-edit-col">
                    <label>
                        <span class="title">Custom Field</span>
                        <input type="text" name="bulk_edit_custom_field" value="">
                    </label>
                </div>
              </fieldset>';
    }
}
add_action('bulk_edit_custom_box', 'autoblog_add_bulk_edit_custom_box', 10, 2);

function autoblog_bulk_edit_save($post_id) {
    if (isset($_REQUEST['bulk_edit_custom_field'])) {
        update_post_meta($post_id, '_custom_field', sanitize_text_field($_REQUEST['bulk_edit_custom_field']));
    }
}
add_action('save_post_autoblog', 'autoblog_bulk_edit_save');

// Tambahkan Metabox untuk Template Autoblog
function autoblog_add_meta_box() {
    add_meta_box('autoblog_settings', 'Autoblog Settings', 'autoblog_meta_box_callback', 'autoblog', 'normal', 'high');
}
add_action('add_meta_boxes', 'autoblog_add_meta_box');

function autoblog_meta_box_callback($post) {
    $apiKey = get_post_meta($post->ID, '_autoblog_api_key', true) ?: 'AIzaSyDdVtEFbUyjQQ2FlkW44546iQXdc56sfeU';
    $model = get_post_meta($post->ID, '_autoblog_model', true) ?: 'gemini-2.0-flash';
    $temperature = get_post_meta($post->ID, '_autoblog_temperature', true) ?: '0.9';
    $max_tokens = get_post_meta($post->ID, '_autoblog_max_tokens', true) ?: '8192';
    $top_p = get_post_meta($post->ID, '_autoblog_top_p', true) ? : '0.9';
    $top_k = get_post_meta($post->ID, '_autoblog_top_k', true) ?:'90';
    $prompt = get_post_meta($post->ID, '_autoblog_prompt', true) ?: 'Buatkan Artikel tentang {keyword} dengan 1.200 kata';
    $keywords = get_post_meta($post->ID, '_autoblog_keywords', true);
	$template = get_post_meta($post->ID, '_autoblog_template_article', true) ?: '[IMAGE][P1]
[P2]
[P3]
[P4]
[P5]
[P6]
[P7]
[P8]
[P9]
[P10]
[P11]
[P12]
[P13]
[P14]
[P15]
[P16]
[P17]
[P18]
[P19]
[P20]
[P21]
[P22]
[P23]
[P24]
[P25]
[P26]
[P27]
[P28]
[P29]
[P30]
[P31]<img src="[IMGSRC2]" alt="[TITLE]" title="[TITLE]">';
    $category = get_post_meta($post->ID, '_autoblog_category', true);
    $tags = get_post_meta($post->ID, '_autoblog_tags', true);
	$image = get_post_meta($post->ID, '_autoblog_image_option', true) ? : '2';
	$image_fail = (int) (get_post_meta($post->ID, '_autoblog_image_fail_action', true) ?: 1);
	$publish = get_post_meta($post->ID, '_autoblog_publish_option', true) ?: 'publish';
    $user_id = get_post_meta($post->ID, '_autoblog_user_id', true);
	$titled = get_post_meta($post->ID, '_autoblog_title', true)?: '[GEMINI]';
	?>
	   
	<label>API Key Gemini:  <a href="https://makersuite.google.com/app/apikey" target="_blank"><strong>Ambil API</strong></a></label>
    <input type="text" name="_autoblog_api_key" value="<?php echo esc_attr($apiKey); ?>" class="widefat">
    
    <label>Model AI: <a href="https://ai.google.dev/gemini-api/docs/models/gemini" target="_blank"><strong>Model AI Tersedia</a></strong></label>
    <input type="text" name="_autoblog_model" value="<?php echo esc_attr($model); ?>" class="widefat">

    <label>Temperature:</label>
    <input type="number" step="0.01" min="0" max="1" name="_autoblog_temperature" value="<?php echo esc_attr($temperature); ?>" class="widefat">
    
    <label>Max Tokens:</label>
    <input type="number" step="32" min="1024" max="8192" name="_autoblog_max_tokens" value="<?php echo esc_attr($max_tokens); ?>" class="widefat">
    
    <label>Top P:</label>
    <input type="number" step="0.01" min="0.01" max="1" name="_autoblog_top_p" value="<?php echo esc_attr($top_p); ?>" class="widefat">
    
    <label>Top K:</label>
    <input type="number" max="100" min="1" step="1" name="_autoblog_top_k" value="<?php echo esc_attr($top_k); ?>" class="widefat"><br/><br/>
	
	<label><strong>Opsi Gambar:</strong></label>
<select name="_autoblog_image_option" class="widefat">
    <option value="1" <?php selected(get_post_meta($post->ID, '_autoblog_image_option', true), '1'); ?>>Hotlink (Ambil dari URL)</option>
    <option value="2" <?php selected(get_post_meta($post->ID, '_autoblog_image_option', true), '2'); ?>>Simpan di Server</option>
    <option value="3" <?php selected(get_post_meta($post->ID, '_autoblog_image_option', true), '3'); ?>>Base64 Encode</option>
</select><br/><br/>
<tr>
    <th scope="row"><label for="_autoblog_image_fail_action"><strong>Gagal Ambil Image</strong></label></th>
    <td>
        <select name="_autoblog_image_fail_action" id="_autoblog_image_fail_action" class="widefat">
            <option value="1" <?php selected(get_post_meta($post->ID, '_autoblog_image_fail_action', true), '1'); ?>>Publish</option>
            <option value="2" <?php selected(get_post_meta($post->ID, '_autoblog_image_fail_action', true), '2'); ?>>Draft</option>
        </select>
        <p class="description">Tentukan status artikel jika gambar gagal diambil.</p>
    </td>
</tr>
<tr>
    <th scope="row"><label for="_autoblog_publish_option"><strong>Publikasi</strong></label></th>
    <td>
        <select name="_autoblog_publish_option" id="_autoblog_publish_option" class="widefat">
		 <option value="publish" <?php selected(get_post_meta($post->ID, '_autoblog_publish_option', true), 'publish'); ?>>Publish</option>
            <option value="draft" <?php selected(get_post_meta($post->ID, '_autoblog_publish_option', true), 'draft'); ?>>Draft</option>
        </select>
        <p class="description">Tentukan apakah artikel langsung publish atau hanya sebagai draft.</p>
    </td>
</tr>
    <label><strong>Template Prompt:</strong></label>
    <textarea name="_autoblog_prompt" class="widefat"><?php echo esc_textarea($prompt); ?></textarea><br/><br/>

    <label><strong>List Keywords (1 per line):</strong></label>
    <textarea name="_autoblog_keywords" rows="15" class="widefat"><?php echo esc_textarea($keywords); ?></textarea><br/><br/>
	
	<label><strong>Template Title:</strong> *<strong>Support : [GEMINI] & [KEYWORD]</strong></label>
    <input type="text" name="_autoblog_title" value="<?php echo esc_attr($titled); ?>" class="widefat">
 
	<label><strong>Template Artikel:</strong></label>
    <textarea name="_autoblog_template_article" rows="20" class="widefat"><?php echo html_entity_decode($template); ?></textarea><br/><br/>

    <label><strong>Kategory:</strong></label>
	<div style="margin-top: 10px;">
    <input type="text" id="new_category_name" placeholder="Tulis Nama Kategori Baru" class="widefat">
    <button type="button" class="button" id="add_new_category_btn">+ Tambah Kategori</button>
</div><br/>
<label><strong>Pilih Kategori:</strong></label>
    <?php
    wp_dropdown_categories([
        'show_option_none' => 'Pilih Kategori',
        'name' => '_autoblog_category',
        'selected' => $category,
        'class' => 'widefat',
        'hide_empty' => false
    ]);
    ?><br/><br/>

    <label><strong>Tags (Pisahkan dengan koma):</strong></label>
    <input type="text" name="_autoblog_tags" value="<?php echo esc_attr($tags); ?>" class="widefat"><br/>
	<label><strong>Tambahkan Admin Baru:</strong></label>
<div style="margin-top: 10px;">
    <input type="text" id="new_admin_username" placeholder="Username Baru" class="widefat">
    <input type="email" id="new_admin_email" placeholder="Email Admin Baru" class="widefat" style="margin-top: 5px;">
    <button type="button" class="button" id="add_new_admin_btn">+ Tambah Admin</button>
</div><br/>

<label><strong>Pilih Admin:</strong></label>
<?php
    wp_dropdown_users([
        'role' => 'administrator',
        'name' => '_autoblog_user_id',
        'selected' => $user_id,
        'class' => 'widefat',
        'show_option_none' => 'Pilih Admin',
    ]);
?><br/><br/>

  <p><strong>URL CronJob:</strong> 
    <a href="<?php echo site_url("?autoblog_cron=1&template_id=" . $post->ID); ?>" target="_blank">
        <?php echo site_url("?autoblog_cron=1&template_id=" . $post->ID); ?>
    </a>
</p>
<button onclick="window.open('<?php echo site_url("?autoblog_cron=1&template_id=" . $post->ID); ?>', '_blank')">Buka Link</button>
<button id="copyButton">Copas Link</button>

<script>
document.getElementById("copyButton").addEventListener("click", function() {
    var link = "<?php echo site_url("?autoblog_cron=1&template_id=" . $post->ID); ?>";
    var tempInput = document.createElement("input");  // Buat input sementara
    tempInput.value = link;
    document.body.appendChild(tempInput);
    tempInput.select();
    tempInput.setSelectionRange(0, 99999); // Untuk kompatibilitas di perangkat mobile
    document.execCommand("copy"); // Menyalin teks ke clipboard
    document.body.removeChild(tempInput); // Hapus input setelah menyalin
    alert("Link berhasil disalin!");
});
</script>
<script>
jQuery(document).ready(function($) {
    $('#add_new_category_btn').on('click', function() {
        var categoryName = $('#new_category_name').val();
        if (!categoryName) {
            alert('Nama kategori tidak boleh kosong.');
            return;
        }

        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'autoblog_add_new_category',
                category_name: categoryName
            },
            success: function(response) {
                if (response.success) {
                    // Tambahkan opsi ke dropdown dan set sebagai selected
                    var option = new Option(response.data.name, response.data.term_id, true, true);
                    $('select[name="_autoblog_category"]').append(option).trigger('change');
                    $('#new_category_name').val('');
                } else {
                    alert(response.data || 'Gagal menambahkan kategori.');
                }
            },
            error: function() {
                alert('Terjadi kesalahan AJAX.');
            }
        });
    });
});
</script>
<script>
jQuery(document).ready(function($) {
    $('#add_new_admin_btn').on('click', function() {
        var username = $('#new_admin_username').val();
        var email = $('#new_admin_email').val();

        if (!username || !email) {
            alert('Isi username dan email.');
            return;
        }

        $.post(ajaxurl, {
            action: 'autoblog_add_new_admin',
            username: username,
            email: email
        }, function(response) {
            if (response.success) {
                alert('Admin berhasil dibuat.');
                var option = new Option(response.data.display_name, response.data.ID, true, true);
                $('select[name="_autoblog_user_id"]').append(option);
                $('#new_admin_username, #new_admin_email').val('');
            } else {
                alert('Gagal: ' + response.data);
            }
        });
    });
});
</script>
    <?php
}

// Simpan Data dari Metabox
function autoblog_save_meta($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;

    foreach (['_autoblog_api_key', '_autoblog_model', '_autoblog_temperature', '_autoblog_max_tokens', '_autoblog_top_p', '_autoblog_top_k', '_autoblog_prompt', '_autoblog_keywords', '_autoblog_template_article', '_autoblog_category', '_autoblog_tags', '_autoblog_image_option','_autoblog_image_fail_action','_autoblog_publish_option','_autoblog_user_id','_autoblog_title'] as $field) {
    if (isset($_POST[$field])) {
        $value = $_POST[$field];

        // Gunakan wp_kses_post untuk mengizinkan HTML yang aman
        $value = wp_kses_post($value);

        update_post_meta($post_id, $field, $value);
    }
}
}
add_action('save_post', 'autoblog_save_meta');
add_action('init', 'autoblog_cronjob');

// Tambahkan halaman admin untuk Cron Runner
function autoblog_add_admin_menu() {
    add_menu_page(
        'GeminiPress', 
        'GeminiPress', 
        'manage_options', 
        'autoblog-cron-runner', 
        'autoblog_cron_runner_page', 
        'dashicons-controls-repeat', 
        25
    );
}
add_action('admin_menu', 'autoblog_add_admin_menu');

function autoblog_cron_runner_page() {
    ?>
    <div class="wrap">
        <h1>🗂️ Posting Massal - GeminiPress</h1>
        <p>Pilih URL CronJob yang ingin dijalankan, atau jalankan semua.</p>

        <div id="cron_list">
            <p><strong>Daftar URL CronJob:</strong></p>
            <button id="load_cron_urls" class="button">Muat URL</button>
            <div id="cron_urls_container" style="border:1px solid #ddd; padding:10px; max-height:200px; overflow:auto; background:#fafafa;"></div>
        </div><br/>

        <label for="cron_delay">Jeda antar request (detik):</label>
        <input type="number" id="cron_delay" value="5" min="1" style="width: 80px;">
		<label for="start_param">Start (hari):</label>
        <input type="number" id="start_param" value="-3" style="width: 80px;">
        <label for="jeda_param">Jarak Waktu Antar Post(menit):</label>
        <input type="number" id="jeda_param" value="10" style="width: 80px;">
        <br/><br/>

        <button id="start_cron" class="button button-primary">Mulai Posting Massal</button>
        <button id="stop_cron" class="button button-secondary">Hentikan</button>

        <p><strong>Hasil:</strong></p>
        <div id="cron_results" style="border:1px solid #ccc; padding:10px; height:300px; overflow:auto; background:#fafafa;"></div>
    </div>

<script>
jQuery(document).ready(function($) {
    var cronUrls = [];
    var isRunning = false;
    var delay = 5000;
    var executionCount = 0;
    var startTimeGlobal = null;
    var intervalID = null;
    var currentIndex = 0;

    function fetchCronUrls() {
        $('#cron_urls_container').html("<p>🔄 Memuat daftar CronJob...</p>");
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: { action: 'autoblog_get_cron_urls' },
            success: function(response) {
                try {
                    var urls = JSON.parse(response);
                    cronUrls = urls;
                    if (urls.length > 0) {
                        var html = "<label><input type='checkbox' id='select_all' /> Pilih Semua</label><br>";
                        urls.forEach((url, index) => {
                            html += `<label><input type='checkbox' class='cron_url' value='${url}' /> ${url}</label><br>`;
                        });
                        $('#cron_urls_container').html(html);
                    } else {
                        $('#cron_urls_container').html("<p>❌ Tidak ada URL CronJob yang tersedia.</p>");
                    }
                } catch (e) {
                    $('#cron_urls_container').html("<p>❌ Gagal memuat daftar CronJob.</p>");
                }
            }
        });
    }

    function updateElapsedTime() {
        let elapsedTime = (new Date() - startTimeGlobal) / 1000;
        let minutes = Math.floor(elapsedTime / 60);
        let seconds = Math.floor(elapsedTime % 60);
        $('#execution_count').text(`🔢 Total Eksekusi: ${executionCount}, ⏳ Total Waktu: ${minutes}m ${seconds}s`);
    }

    function runCronJob(selectedUrls) {
        if (!isRunning) {
            $('#cron_results').append("<p>✅ Proses dihentikan!</p>");
            clearInterval(intervalID);
            return;
        }

        if (currentIndex >= selectedUrls.length) {
            currentIndex = 0;
        }

        let baseUrl = selectedUrls[currentIndex];
        executionCount++;

        // Ambil input user
        let startParam = $('#start_param').val();
        let jedaAwal = parseInt($('#jeda_param').val()) || 0;

        // Hitung jeda berdasarkan eksekusi ke berapa
        let totalJeda = jedaAwal * executionCount;

        // Tambahkan parameter ke URL
        let url = "";
        if (baseUrl.includes('?')) {
            url = `${baseUrl}&start=${startParam}&jeda=${totalJeda}`;
        } else {
            url = `${baseUrl}?start=${startParam}&jeda=${totalJeda}`;
        }

        let startTime = new Date();
        $('#cron_results').append(`<p>🚀 [${executionCount}] Memproses: <strong>${url}</strong> (Mulai: ${startTime.toLocaleTimeString()})</p>`);
        updateElapsedTime();

        $.ajax({
            url: url,
            success: function(response) {
                let endTime = new Date();
                let duration = (endTime - startTime) / 1000;
                $('#cron_results').append(`
                    <p>✅ Selesai: <strong>${url}</strong> (Durasi: ${duration} detik)</p>
                    <p><pre>${response}</pre></p>
                `);
            },
            error: function(xhr, status, error) {
                let endTime = new Date();
                let duration = (endTime - startTime) / 1000;
                $('#cron_results').append(`<p>❌ Gagal: <strong>${url}</strong> (Durasi: ${duration} detik) - ${status}</p>`);
            },
            complete: function() {
                currentIndex++;
                $('#cron_results').append(`<p>⏳ Menunggu ${delay / 1000} detik sebelum eksekusi berikutnya...<br/></p>`);
                setTimeout(function() {
                    runCronJob(selectedUrls);
                }, delay);
            }
        });
    }

    $('#load_cron_urls').click(fetchCronUrls);

    $('#start_cron').click(function() {
        delay = parseInt($('#cron_delay').val()) * 1000;
        isRunning = true;
        executionCount = 0;
        startTimeGlobal = new Date();
        currentIndex = 0;

        clearInterval(intervalID);
        intervalID = setInterval(updateElapsedTime, 1000);

        let selectedUrls = [];
        $('.cron_url:checked').each(function() {
            selectedUrls.push($(this).val());
        });

        if (selectedUrls.length === 0) {
            $('#cron_results').html("<p>⚠️ Pilih minimal satu URL CronJob untuk dijalankan.</p>");
            return;
        }

        $('#cron_results').html("<p>🔄 Memulai CronJob...</p>");
        $('#execution_count').text("🔢 Total Eksekusi: 0");
        runCronJob(selectedUrls);
    });

    $('#stop_cron').click(function() {
        isRunning = false;
        clearInterval(intervalID);
        $('#cron_results').append("<p>⏹️ Proses dihentikan!</p>");
    });

    $(document).on('change', '#select_all', function() {
        $('.cron_url').prop('checked', this.checked);
    });
});
</script>
<!-- Tambahkan elemen untuk menampilkan jumlah eksekusi -->
<p id="execution_count">🔢 Total Eksekusi: 0</p>
    <?php
}


// Fungsi untuk mendapatkan daftar URL CronJob
function autoblog_get_cron_urls() {
    $args = array(
        'post_type'      => 'autoblog',
        'posts_per_page' => -1,
    );
    $posts = get_posts($args);

    $cron_urls = [];
    foreach ($posts as $post) {
        $cron_urls[] = site_url("?autoblog_cron=1&template_id=" . $post->ID);
    }

    echo json_encode($cron_urls);
    wp_die();
}
add_action('wp_ajax_autoblog_get_cron_urls', 'autoblog_get_cron_urls');


add_action('template_redirect', function () {
    if (is_singular('autoblog')) {
        global $post;

        // Buat URL CronJob berdasarkan format yang kamu minta
        $cron_url = site_url("?autoblog_cron=1&template_id=" . $post->ID);

        // Redirect ke URL CronJob
        wp_redirect($cron_url, 301);
        exit;
    }
});

// Tambahkan submenu untuk Lisensi, Panduan, dan List Post ke AI Bulk Post
function autoblog_add_submenus() {
    // Submenu untuk List Post (CPT: autoblog)
	add_submenu_page(
        'autoblog-cron-runner', 
        '🗂️ Posting Massal', 
        '🗂️ Posting Massal', 
        'manage_options', 
        'admin.php?page=autoblog-cron-runner'
    );
	add_submenu_page(
        'autoblog-cron-runner', 
        '🆕 Bikin Template Baru', 
        '🆕 Bikin Template', 
        'manage_options', 
        'post-new.php?post_type=autoblog'
    );
    add_submenu_page(
        'autoblog-cron-runner', 
        '📝 List Template', 
        '📝 List Template', 
        'manage_options', 
        'edit.php?post_type=autoblog'
    );

    // Submenu untuk Panduan Penggunaan
    add_submenu_page(
        'autoblog-cron-runner', 
        '📖 Panduan Penggunaan', 
        '📖 Panduan', 
        'manage_options', 
        'autoblog-guide', 
        'autoblog_guide_page'
    );

    // Submenu untuk Lisensi
    add_submenu_page(
        'autoblog-cron-runner', 
        '🗝️ Lisensi', 
        '🗝️ Lisensi', 
        'manage_options', 
        'autoblog-license', 
        'autoblog_license_page'
    );
	add_submenu_page(
        'autoblog-cron-runner', 
        '🗝️ Bing Auto Indexing', 
        '🗝️ Bing Indexing', 
        'manage_options', 
        'autoblog-bingapi', 
        'autoblog_bingapi_page'
    );
}
add_action('admin_menu', 'autoblog_add_submenus');

// Fungsi untuk halaman Panduan
function autoblog_guide_page() {
    echo '<div class="wrap">';
    echo '<h2>Panduan Penggunaan GeminiPress</h2>';
    echo '<p>GeminiPress adalah plugin autoblog berbasis AI yang menggunakan API Gemini dari Google AI untuk menghasilkan artikel otomatis.</p>';

    // Konfigurasi API
    echo '<h3>1. Konfigurasi API</h3>';
    echo '<table class="widefat">
            <tr><th>Pengaturan</th><th>Keterangan</th></tr>
            <tr><td><strong>API Key Gemini</strong></td><td><a href="https://ai.google.dev/" target="_blank">Ambil API Key</a></td></tr>
            <tr><td><strong>Model AI</strong></td><td><a href="https://ai.google.dev/models" target="_blank">Daftar Model AI</a></td></tr>
          </table>';

    // Pengaturan AI
    echo '<h3>2. Pengaturan AI</h3>';
    echo '<table class="widefat">
            <tr><th>Pengaturan</th><th>Keterangan</th></tr>
            <tr><td><strong>Temperature</strong></td><td>Mengontrol kreativitas (0.0 = faktual, 1.0 = kreatif). Rekomendasi: 0.7.</td></tr>
            <tr><td><strong>Max Tokens</strong></td><td>Batas jumlah token dalam artikel (Maksimum: 8192 tokens).</td></tr>
            <tr><td><strong>Top P</strong></td><td>Probabilitas sampling kata (0.1 = sangat ketat, 0.9 = lebih bervariasi). Rekomendasi: 0.7.</td></tr>
            <tr><td><strong>Top K</strong></td><td>Jumlah kata yang dipertimbangkan AI (1 = sangat terbatas, 100 = lebih luas). Rekomendasi: 40-80.</td></tr>
          </table>';

    // Template Prompt
    echo '<h3>3. Template Prompt</h3>';
    echo '<p>Berikan instruksi jelas kepada AI agar artikel sesuai keinginan. Contoh:</p>';
    echo '<pre>Buatkan artikel tentang {keyword} dengan gaya bahasa storytelling.</pre>';

    // Format Template Artikel
    echo '<h3>4. Format Template Artikel</h3>';
    echo '<table class="widefat">
	        <tr><td><strong>[TITLE]</strong></td><td>Judul Artikel</td></tr>
            <tr><td><strong>[P1] - [P30]</strong></td><td>Setiap paragraf dari 1 hingga 30.</td></tr>
            <tr><td><strong>[P31]</strong></td><td>Paragraf 31 hingga akhir.</td></tr>
			<tr><td><strong>[IMAGE]</strong></td><td>Tampilkan Gambar Feature di Artikel.</td></tr>
			<tr><td><strong>[IMGSRC]</strong></td><td>URL Gambar Pertama dan Utama.</td></tr>
            <tr><td><strong>[IMGSRC2] - [IMGSRC30]</strong></td><td>URL Gambar Kedua s.d. URL Gambar ke-30.</td></tr>
			<tr><td><strong>[TOC]</strong></td><td>Table of Contents atau Daftar Isi Permanen tanpa Plugin.</td></tr>
			<tr><td><strong>[VIDEO]</strong></td><td>Embed Video Youtube (jika ada), Sesuai Judul Artikel.</td></tr>
			<tr><td><strong>[RELATED]</strong></td><td>Artikel Terkait sesuai Kategori yang dipilih.</td></tr>

		  </table>';

    // CronJob
    echo '<h3>5. Penggunaan CronJob</h3>';
    echo '<p>Gunakan URL ini untuk menjalankan artikel otomatis via CronJob:</p>';
    echo '<pre><code>' . site_url('/?autoblog_cron=1&template_id=YOUR_TEMPLATE_ID') . '</code></pre>';
    echo '<p><strong>Cara Menggunakan:</strong></p>';
    echo '<ol>
            <li>Buka cPanel atau terminal server Anda.</li>
            <li>Tambahkan perintah CronJob dengan format:<br><pre>*/10 * * * * wget -q -O - "' . site_url('/?autoblog_cron=1&template_id=YOUR_TEMPLATE_ID') . '"</pre></li>
            <li>Atur waktu eksekusi sesuai kebutuhan.</li>
          </ol>';

    echo '</div>';
}


// Fungsi untuk halaman Lisensi
function autoblog_license_page() {
    if (isset($_POST['autoblog_license_key'])) {
        update_option('autoblog_license_key', sanitize_text_field($_POST['autoblog_license_key']));
        echo '<div class="updated"><p>Lisensi berhasil disimpan!</p></div>';
    }

    $license_key = get_option('autoblog_license_key', '');

    echo '<div class="wrap"><h2>Lisensi</h2>';
    echo '<form method="post">';
    echo '<textarea name="autoblog_license_key" rows="5" style="width: 100%;">' . esc_textarea($license_key) . '</textarea>';
    echo '<br><input type="submit" value="Simpan Lisensi" class="button button-primary">';
    echo '</form></div>';
}
add_action('wp_ajax_autoblog_add_new_category', 'autoblog_add_new_category_callback');
function autoblog_add_new_category_callback() {
    if (!current_user_can('manage_categories')) {
        wp_send_json_error('Tidak punya izin.');
    }

    $cat_name = sanitize_text_field($_POST['category_name']);

    if (empty($cat_name)) {
        wp_send_json_error('Nama kategori kosong.');
    }

    $result = wp_insert_term($cat_name, 'category');

    if (is_wp_error($result)) {
        wp_send_json_error($result->get_error_message());
    }

    wp_send_json_success([
        'term_id' => $result['term_id'],
        'name'    => $cat_name
    ]);
}
add_action('wp_ajax_autoblog_add_new_admin', 'autoblog_add_new_admin_callback');
function autoblog_add_new_admin_callback() {
    if (!current_user_can('create_users')) {
        wp_send_json_error('Tidak diizinkan.');
    }

    $username = sanitize_user($_POST['username']);
    $email = sanitize_email($_POST['email']);

    if (username_exists($username) || email_exists($email)) {
        wp_send_json_error('Username atau email sudah ada.');
    }

    $random_password = wp_generate_password(12, true);
    $user_id = wp_create_user($username, $random_password, $email);

    if (is_wp_error($user_id)) {
        wp_send_json_error($user_id->get_error_message());
    }

    $user = new WP_User($user_id);
    $user->set_role('administrator');

    wp_send_json_success([
        'ID' => $user_id,
        'display_name' => $user->display_name ?: $username
    ]);
}
function autoblog_register_bingapi_setting() {
    register_setting('autoblog_settings_group', 'autoblog_bing_api_key');

    add_settings_section('autoblog_section', 'Pengaturan Umum', null, 'autoblog-settings');

    add_settings_field(
        'autoblog_bing_api_key',
        'Bing Auto Indexing API Key :',
        function () {
            $value = esc_attr(get_option('autoblog_bing_api_key'));
            echo '<input type="text" name="autoblog_bing_api_key" value="' . $value . '" class="regular-text">
			<br/><br/><label><a href="https://www.bing.com/webmasters/apps/apiaccess" target="_blank">🔗 <strong>Dapatkan Bing Auto Indexing API Key di sini</strong></a></label>';
        },
        'autoblog-settings',
        'autoblog_section'
    );
}
add_action('admin_init', 'autoblog_register_bingapi_setting');

// Fungsi untuk menampilkan halaman submenu
function autoblog_bingapi_page() {
    ?>
    <div class="wrap">
        <h1>Bing Auto Indexing API Key</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('autoblog_settings_group');
            do_settings_sections('autoblog-settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}
add_filter('plugin_row_meta', 'autoblog_plugin_row_meta', 10, 2);

function autoblog_plugin_row_meta($links, $file) {
    if ($file === plugin_basename(__FILE__)) {
        $links[] = '<a href="' . admin_url('admin.php?page=autoblog-guide') . '" target="_blank">📘 Tutorial</a>';
        $links[] = '<a href="https://wa.me/6285643434382" target="_blank">💬 Chat WA</a>';
    }
    return $links;
}

add_filter('site_transient_update_plugins', 'autoblog_check_for_plugin_update');
add_filter('plugins_api', 'autoblog_plugin_api_call', 10, 3);

function autoblog_check_for_plugin_update($transient) {
    if (empty($transient->checked)) return $transient;

    $remote = get_transient('autoblog_plugin_update');

    if (!$remote) {
        $response = wp_remote_get('https://update.ebot.my.id/geminipress.json', [
            'timeout' => 10,
            'headers' => ['Accept' => 'application/json']
        ]);

        if (!is_wp_error($response) && isset($response['body'])) {
            $remote = json_decode($response['body']);
            set_transient('autoblog_plugin_update', $remote, 1 * HOUR_IN_SECONDS);
        }
    }

    // Mengambil nama plugin secara dinamis
    $plugin_slug = plugin_basename(__FILE__);
    if (!function_exists('get_plugin_data')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }

    // Mendapatkan data plugin dengan path dinamis
    $plugin_data = get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin_slug);

    if (
        $remote
        && version_compare($plugin_data['Version'], $remote->version, '<')
    ) {
        $transient->response[$plugin_slug] = (object)[
            'slug' => $plugin_slug,
            'plugin' => $plugin_slug,
            'new_version' => $remote->version,
            'url' => $remote->homepage,
            'package' => $remote->download_url,
        ];
    }

    return $transient;
}

function autoblog_plugin_api_call($result, $action, $args) {
    if ($action !== 'plugin_information') return $result;

    // Memastikan plugin yang dimaksud sesuai dengan slug plugin dinamis
    $plugin_slug = plugin_basename(__FILE__);
    if ($args->slug !== $plugin_slug) return $result;

    $remote = get_transient('autoblog_plugin_update');

    if (!$remote) {
        $response = wp_remote_get('https://update.ebot.my.id/geminipress.json', [
            'timeout' => 10,
            'headers' => ['Accept' => 'application/json']
        ]);

        if (!is_wp_error($response) && isset($response['body'])) {
            $remote = json_decode($response['body']);
            set_transient('autoblog_plugin_update', $remote, 12 * HOUR_IN_SECONDS);
        }
    }

    if ($remote) {
        $res = new stdClass();
        $res->name = $remote->name;
        $res->slug = $remote->slug;
        $res->version = $remote->version;
        $res->author = $remote->author;
        $res->homepage = $remote->homepage;
        $res->download_link = $remote->download_url;

        foreach ($remote->sections as $key => $value) {
            $res->sections[$key] = $value;
        }

        return $res;
    }

    return $result;
}
add_action('admin_menu', 'autoblog_indexnow_menu');
function autoblog_indexnow_menu() {
    add_submenu_page(
        'autoblog-cron-runner',
        '📥 IndexNow Settings',
        '📥 IndexNow',
        'manage_options',
        'autoblog-indexnow',
        'autoblog_indexnow_page'
    );
}

function autoblog_indexnow_page() {
    $saved_api = get_option('autoblog_indexnow_apikey', '');

    // Tangani generate API Key
    if (isset($_POST['generate_random_api']) && check_admin_referer('submit_indexnow_api_action', 'submit_indexnow_api_nonce')) {
        $random_key = 'apikey-' . wp_generate_password(16, false);
        $_POST['indexnow_api'] = $random_key; // Set agar langsung diproses bagian bawah
        $_POST['submit_indexnow_api'] = true;
    }

    // Tangani simpan API Key
    if (isset($_POST['submit_indexnow_api']) && check_admin_referer('submit_indexnow_api_action', 'submit_indexnow_api_nonce')) {
        $api_key = sanitize_file_name($_POST['indexnow_api']);

        // Jika kosong, hapus opsi & file lama
        if (empty($api_key)) {
            delete_option('autoblog_indexnow_apikey');

            if (!empty($saved_api)) {
                $old_file = ABSPATH . $saved_api . '.txt';
                if (file_exists($old_file)) {
                    unlink($old_file);
                }
            }

            echo '<div class="notice notice-warning is-dismissible"><p>⚠️ API Key dikosongkan. File dan opsi telah dihapus.</p></div>';
            $saved_api = '';
        } else {
            // Simpan dan buat file
            update_option('autoblog_indexnow_apikey', $api_key);
            $file_path = ABSPATH . $api_key . '.txt';

            if (file_put_contents($file_path, $api_key) !== false) {
                echo '<div class="notice notice-success is-dismissible"><p>✅ File <code>' . esc_html($api_key) . '.txt</code> berhasil dibuat dan API Key disimpan.</p></div>';
            } else {
                echo '<div class="notice notice-error is-dismissible"><p>❌ Gagal membuat file <code>' . esc_html($api_key) . '.txt</code> di root WordPress.</p></div>';
            }

            $saved_api = $api_key;
        }
    }

    ?>
    <div class="wrap">
        <h1>📥 IndexNow Settings</h1>
        <form method="post">
            <?php wp_nonce_field('submit_indexnow_api_action', 'submit_indexnow_api_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="indexnow_api">Nama API Key (.txt)</label></th>
                    <td>
                        <input type="text" id="indexnow_api" name="indexnow_api" value="<?php echo esc_attr($saved_api); ?>" class="regular-text" />
                        <p class="description">Contoh: jika kamu isi <code>rifanmuazin</code>, maka akan dibuat file <code>rifanmuazin.txt</code> di root folder WordPress dengan isi yang sama.</p>
                        <p class="description"><strong>Kosongkan</strong> kolom lalu klik Simpan untuk menghapus API Key & file lama.</p>
                    </td>
                </tr>
            </table>
            <p>
                <input type="submit" name="submit_indexnow_api" class="button button-primary" value="Simpan API Key" />
                <input type="submit" name="generate_random_api" class="button button-secondary" value="🔑 Generate API Key Acak" />
            </p>
        </form>
    </div>
    <?php
}
